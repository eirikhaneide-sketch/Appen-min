package com.destim.app

import android.app.*
import android.app.usage.UsageStatsManager
import android.content.*
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.*
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var usm: UsageStatsManager
    private var firstRun = false
    private var screenMinutes = 0L
    private var openings = 0
    private var eveningMinutes = 0L
    private val prefs by lazy { getSharedPreferences("destim", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var timerRunnable: Runnable? = null

    private fun isHomeIntent(intent: Intent?): Boolean {
        return intent?.action == Intent.ACTION_MAIN &&
            intent.categories?.contains(Intent.CATEGORY_HOME) == true
    }

    private fun openHomeLauncher() {
        if (prefs.getBoolean("dumb_active", false)) {
            showDumbPhone()
        } else {
            showLauncherIdle()
        }
    }

    private fun showLauncherIdle() {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(34, 54, 34, 30)
            setBackgroundColor(Color.BLACK)
        }

        r.addView(TextView(this).apply {
            text = "DESTIM"
            textSize = 13f
            setTextColor(Color.rgb(140,140,140))
            gravity = Gravity.CENTER
            letterSpacing = .18f
        })
        r.addView(gap(28))

        val clock = TextView(this).apply {
            textSize = 54f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        r.addView(clock)

        r.addView(gap(6))
        r.addView(TextView(this).apply {
            text = "MINIMAL HOME"
            textSize = 11f
            setTextColor(Color.rgb(100,100,100))
            gravity = Gravity.CENTER
            letterSpacing = .12f
        })
        r.addView(gap(34))

        r.addView(TextView(this).apply {
            text = "START DUMB PHONE"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(18, 18, 18, 18)
            setOnClickListener { showDumbPhoneSetup() }
        })
        r.addView(gap(10))

        r.addView(TextView(this).apply {
            text = "OPEN DESTIM"
            textSize = 13f
            setTextColor(Color.rgb(150,150,150))
            gravity = Gravity.CENTER
            setPadding(18, 14, 18, 14)
            setOnClickListener { showHome() }
        })

        val update = object : Runnable {
            override fun run() {
                val now = Calendar.getInstance()
                clock.text = String.format(
                    Locale.getDefault(), "%02d:%02d",
                    now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE)
                )
                handler.postDelayed(this, 1000L)
            }
        }
        timerRunnable = update
        handler.post(update)
        setContentView(r)
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        if (isHomeIntent(intent)) {
            openHomeLauncher()
            return
        }
        usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        firstRun = !prefs.getBoolean("disclosure_seen", false)

        if (prefs.getBoolean("dumb_active", false)) {
            showDumbPhone()
        } else if (prefs.getBoolean("simple_mode_active", false)) {
            showSimpleModeActive(prefs.getString("simple_mode_name", "FOCUS") ?: "FOCUS", "ONE THING AT A TIME", 60L)
        } else if (firstRun) {
            showPrivacyDisclosure()
        } else {
            refresh()
            showHome()
        }
    }

    override fun onBackPressed() {
        if (prefs.getBoolean("dumb_active", false)) {
            // Keep the Dumb Phone surface stable. The explicit END SESSION
            // control is the intentional exit path.
            return
        }
        super.onBackPressed()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (isHomeIntent(intent)) {
            openHomeLauncher()
        }
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("dumb_active", false)) {
            showDumbPhone()
        } else if (prefs.getBoolean("simple_mode_active", false)) {
            showSimpleModeActive(prefs.getString("simple_mode_name", "FOCUS") ?: "FOCUS", "ONE THING AT A TIME", 60L)
        } else if (!firstRun && ::usm.isInitialized) {
            refresh()
            showHome()
        }
    }

    override fun onDestroy() {
        timerRunnable?.let { handler.removeCallbacks(it) }
        super.onDestroy()
    }

    private fun showPrivacyDisclosure() {
        val r = root()
        r.addView(t("DESTIM", 18f, true))
        r.addView(gap(24))
        r.addView(t("SEE YOUR PHONE CLEARLY.", 28f, true))
        r.addView(gap(10))
        r.addView(t(
            "DESTIM uses Android usage data to show screen time, app use, app openings and evening use. " +
            "This data is processed locally on your device in this version. It is not sold or used for advertising.",
            15f
        ))
        r.addView(gap(12))
        r.addView(t(
            "You choose whether to grant Usage Access. DESTIM will not collect usage data before you give permission.",
            14f
        ))
        r.addView(gap(18))
        r.addView(btn("I UNDERSTAND", {
            prefs.edit().putBoolean("disclosure_seen", true).apply()
            firstRun = false
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }))
        r.addView(gap(8))
        r.addView(btn("CONTINUE WITHOUT USAGE DATA", {
            prefs.edit().putBoolean("disclosure_seen", true).apply()
            firstRun = false
            showHome()
        }))
        setContentView(r)
    }

    private fun refresh() {
        val start = dayStart()
        val end = System.currentTimeMillis()
        val stats = usm.queryAndAggregateUsageStats(start, end)
        screenMinutes = stats.values.sumOf { it.totalTimeInForeground / 60000L }
        openings = countOpenings(start, end)
        eveningMinutes = eveningUse()
    }

    private fun dayStart(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun eveningUse(): Long {
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 18); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        return usm.queryAndAggregateUsageStats(maxOf(dayStart(), start), System.currentTimeMillis())
            .values.sumOf { it.totalTimeInForeground / 60000L }
    }

    private fun countOpenings(start: Long, end: Long): Int {
        val events = usm.queryEvents(start, end) ?: return 0
        val e = android.app.usage.UsageEvents.Event()
        val seen = mutableSetOf<String>()
        var count = 0
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                val pkg = e.packageName ?: continue
                if (pkg != packageName && seen.add("${pkg}_${e.timeStamp / 60000}")) count++
            }
        }
        return count
    }

    private fun score(): Int {
        val screen = minOf(100, (screenMinutes / 360.0 * 100).roundToInt())
        val unlock = minOf(100, (openings / 150.0 * 100).roundToInt())
        val evening = minOf(100, (eveningMinutes / 120.0 * 100).roundToInt())
        return ((screen * .45) + (unlock * .25) + (evening * .30)).roundToInt()
    }

    private fun showHome() {
        val r = root()
        r.addView(t("DESTIM", 16f, true))
        r.addView(gap(10))
        r.addView(t(score().toString(), 70f, true).apply { gravity = Gravity.CENTER })
        r.addView(t("STIMULI SCORE", 13f, true).apply { gravity = Gravity.CENTER })
        r.addView(t("Based on your phone use today", 13f).apply { gravity = Gravity.CENTER })
        r.addView(gap(16))
        r.addView(t("YOUR PHONE TODAY", 13f, true))
        metric(r, format(screenMinutes), "Screen time")
        metric(r, openings.toString(), "App openings")
        metric(r, format(eveningMinutes), "Evening use")
        r.addView(gap(8))
        r.addView(btn("VIEW DETAILS", ::showDetails))
        r.addView(gap(8))
        r.addView(t("QUICK ACTIONS", 13f, true))
        r.addView(btn("DUMB PHONE", ::showDumbPhoneSetup))
        r.addView(btn("FOCUS", ::showFocusMode))
        r.addView(btn("SLEEP", ::showSleepMode))
        r.addView(gap(8))
        r.addView(btn("SETTINGS", ::showSettings))
        setContentView(r)
    }

    private fun showDetails() {
        val r = root()
        r.addView(t("STIMULI SCORE", 16f, true))
        r.addView(gap(8))
        r.addView(t(score().toString(), 54f, true))
        r.addView(t("What created today's score", 14f, true))
        r.addView(gap(8))
        metric(r, format(screenMinutes), "Screen time · 45%")
        metric(r, openings.toString(), "App openings · 25%")
        metric(r, format(eveningMinutes), "Evening use · 30%")
        r.addView(gap(12))
        r.addView(t("HOW IT WORKS", 13f, true))
        r.addView(t(
            "The score is an indicator of digital stimulation. It is deliberately transparent and is not a medical measurement.",
            14f
        ))
        r.addView(gap(12))
        r.addView(btn("BACK", ::showHome))
        setContentView(r)
    }

    private data class LaunchableApp(val label: String, val packageName: String)

    private fun launchableApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { ri ->
                val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == packageName) return@mapNotNull null
                val label = ri.loadLabel(packageManager)?.toString()?.trim().orEmpty()
                if (label.isBlank()) null else LaunchableApp(label, pkg)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun defaultPackages(): Set<String> {
        val apps = launchableApps()
        val wanted = listOf("phone", "messages", "messaging", "maps", "music", "camera")
        return apps.filter { a ->
            val s = a.label.lowercase(Locale.getDefault())
            wanted.any { s.contains(it) }
        }.take(5).map { it.packageName }.toSet()
    }

    private fun showDumbPhoneSetup() {
        val apps = launchableApps()
        val saved = prefs.getStringSet("dumb_apps", null)?.toMutableSet() ?: defaultPackages().toMutableSet()
        val selected = saved.intersect(apps.map { it.packageName }.toSet()).toMutableSet()

        val r = root()
        r.addView(t("DUMB PHONE", 20f, true))
        r.addView(gap(4))
        r.addView(t("Choose what stays available. DESTIM will show only these apps during the session.", 14f))
        r.addView(gap(12))

        val profileRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        profileRow.addView(btn("ESSENTIAL") {
            selected.clear()
            selected.addAll(defaultPackages())
            showDumbPhoneSetup()
        }, LinearLayout.LayoutParams(0, 52, 1f))
        profileRow.addView(btn("MINIMAL") {
            selected.clear()
            selected.addAll(defaultPackages().take(2))
            showDumbPhoneSetup()
        }, LinearLayout.LayoutParams(0, 52, 1f))
        profileRow.addView(btn("CUSTOM") {
            // Keep current selections; app list below is the editor.
            toast("Choose your apps below")
        }, LinearLayout.LayoutParams(0, 52, 1f))
        r.addView(profileRow)

        r.addView(gap(10))
        r.addView(t("AVAILABLE APPS", 13f, true))

        val checks = mutableMapOf<String, CheckBox>()
        apps.forEach { app ->
            val cb = CheckBox(this).apply {
                text = app.label
                textSize = 15f
                isChecked = selected.contains(app.packageName)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(app.packageName) else selected.remove(app.packageName)
                }
            }
            checks[app.packageName] = cb
            r.addView(cb)
        }

        r.addView(gap(10))
        r.addView(t("DURATION", 13f, true))
        val durations = listOf("30 MIN" to 30L, "1 HOUR" to 60L, "2 HOURS" to 120L, "UNTIL MORNING" to -1L)
        val durationGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        var durationMinutes = prefs.getLong("dumb_duration", 60L)
        durations.forEach { (label, minutes) ->
            val rb = RadioButton(this).apply {
                text = label
                textSize = 15f
                isChecked = durationMinutes == minutes
                setOnClickListener { durationMinutes = minutes }
            }
            durationGroup.addView(rb)
        }
        r.addView(durationGroup)

        r.addView(gap(10))
        r.addView(btn("ACTIVATE DUMB PHONE") {
            if (selected.isEmpty()) {
                toast("Choose at least one app")
                return@btn
            }
            prefs.edit()
                .putStringSet("dumb_apps", selected)
                .putLong("dumb_duration", durationMinutes)
                .apply()
            activateDumbPhone(durationMinutes)
        })
        r.addView(btn("BACK", ::showHome))
        setContentView(r)
    }

    private fun activateDumbPhone(durationMinutes: Long) {
        val end = if (durationMinutes < 0) nextMorning() else System.currentTimeMillis() + durationMinutes * 60_000L
        prefs.edit()
            .putBoolean("dumb_active", true)
            .putLong("dumb_end", end)
            .apply()
        showDumbPhone()
    }

    private fun nextMorning(): Long {
        return Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 7)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    private fun showDumbPhone() {
        timerRunnable?.let { handler.removeCallbacks(it) }

        val end = prefs.getLong("dumb_end", 0L)
        if (end <= System.currentTimeMillis()) {
            endDumbPhone()
            return
        }

        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(34, 48, 34, 28)
            setBackgroundColor(Color.BLACK)
        }

        r.addView(TextView(this).apply {
            text = "DESTIM"
            textSize = 13f
            setTextColor(Color.rgb(150,150,150))
            gravity = Gravity.CENTER
            letterSpacing = .18f
        })
        r.addView(gap(30))

        r.addView(TextView(this).apply {
            text = "DUMB PHONE"
            textSize = 14f
            setTextColor(Color.rgb(155,155,155))
            gravity = Gravity.CENTER
            letterSpacing = .16f
        })

        val clock = TextView(this).apply {
            textSize = 52f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        r.addView(clock)

        val countdown = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.rgb(150,150,150))
            gravity = Gravity.CENTER
        }
        r.addView(countdown)
        r.addView(gap(28))

        val line = View(this).apply {
            setBackgroundColor(Color.rgb(55,55,55))
        }
        r.addView(line, LinearLayout.LayoutParams(-1, 1))
        r.addView(gap(10))

        val allowed = prefs.getStringSet("dumb_apps", emptySet()) ?: emptySet()
        val apps = launchableApps().filter { allowed.contains(it.packageName) }

        apps.forEach { app ->
            val appButton = TextView(this).apply {
                text = app.label
                textSize = 18f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 14, 8, 14)
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                    if (launch != null) startActivity(launch) else toast("Cannot open ${app.label}")
                }
            }
            r.addView(appButton, LinearLayout.LayoutParams(-1, 54))
        }

        r.addView(gap(8))
        val bottomLine = View(this).apply {
            setBackgroundColor(Color.rgb(55,55,55))
        }
        r.addView(bottomLine, LinearLayout.LayoutParams(-1, 1))
        r.addView(gap(10))

        r.addView(TextView(this).apply {
            text = "END SESSION"
            textSize = 13f
            setTextColor(Color.rgb(155,155,155))
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 12)
            setOnClickListener { confirmEndDumbPhone() }
        })

        r.addView(TextView(this).apply {
            text = "EDIT PROFILE"
            textSize = 12f
            setTextColor(Color.rgb(100,100,100))
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
            setOnClickListener { showDumbPhoneSetup() }
        })

        val update = object : Runnable {
            override fun run() {
                if (!prefs.getBoolean("dumb_active", false)) return
                val remaining = prefs.getLong("dumb_end", 0L) - System.currentTimeMillis()
                if (remaining <= 0L) {
                    endDumbPhone()
                } else {
                    val now = Calendar.getInstance()
                    clock.text = String.format(
                        Locale.getDefault(), "%02d:%02d",
                        now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE)
                    )
                    countdown.text = formatCountdown(remaining)
                    handler.postDelayed(this, 1000L)
                }
            }
        }
        timerRunnable = update
        handler.post(update)
        setContentView(r)
    }

    private fun formatCountdown(ms: Long): String {
        val total = ms / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s)
        else String.format(Locale.getDefault(), "%02d:%02d", m, s)
    }

    private fun confirmEndDumbPhone() {
        AlertDialog.Builder(this)
            .setTitle("End Dumb Phone?")
            .setMessage("You can end the session early. There is no penalty.")
            .setNegativeButton("KEEP GOING", null)
            .setPositiveButton("END", { _, _ -> endDumbPhone() })
            .show()
    }

    private fun endDumbPhone() {
        timerRunnable?.let { handler.removeCallbacks(it) }
        prefs.edit().putBoolean("dumb_active", false).remove("dumb_end").apply()
        refresh()
        showHome()
        toast("Dumb Phone ended")
    }


    private fun showFocusMode() {
        showSimpleMode("FOCUS", "ONE THING AT A TIME", 60L)
    }

    private fun showSleepMode() {
        showSimpleMode("SLEEP", "PUT THE PHONE DOWN", -1L)
    }

    private fun showSimpleMode(title: String, subtitle: String, defaultMinutes: Long) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(34, 40, 34, 34)
            setBackgroundColor(Color.BLACK)
        }

        r.addView(TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.rgb(150,150,150))
            gravity = Gravity.CENTER
            letterSpacing = .18f
        })
        r.addView(gap(18))
        r.addView(TextView(this).apply {
            text = subtitle
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        r.addView(gap(14))
        r.addView(TextView(this).apply {
            text = if (title == "SLEEP") "Minimal mode until morning." else "A quiet screen for focused work."
            textSize = 14f
            setTextColor(Color.rgb(145,145,145))
            gravity = Gravity.CENTER
        })
        r.addView(gap(32))

        val duration = TextView(this).apply {
            text = if (defaultMinutes < 0) "UNTIL 07:00" else "${defaultMinutes.toInt()} MIN"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(18, 16, 18, 16)
        }
        r.addView(duration)

        r.addView(gap(22))
        r.addView(TextView(this).apply {
            text = "ACTIVATE"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(20, 16, 20, 16)
            setOnClickListener {
                prefs.edit()
                    .putBoolean("simple_mode_active", true)
                    .putString("simple_mode_name", title)
                    .apply()
                showSimpleModeActive(title, subtitle, defaultMinutes)
            }
        })
        r.addView(gap(8))
        r.addView(TextView(this).apply {
            text = "BACK"
            textSize = 12f
            setTextColor(Color.rgb(110,110,110))
            gravity = Gravity.CENTER
            setPadding(20, 12, 20, 12)
            setOnClickListener { showHome() }
        })

        setContentView(r)
    }

    private fun showSimpleModeActive(title: String, subtitle: String, durationMinutes: Long) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(34, 40, 34, 34)
            setBackgroundColor(Color.BLACK)
        }

        r.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(Color.rgb(130,130,130))
            gravity = Gravity.CENTER
            letterSpacing = .18f
        })
        r.addView(gap(22))

        val clock = TextView(this).apply {
            textSize = 54f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        r.addView(clock)

        r.addView(gap(8))
        r.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(Color.rgb(130,130,130))
            gravity = Gravity.CENTER
        })
        r.addView(gap(34))

        r.addView(TextView(this).apply {
            text = "THE PHONE CAN WAIT."
            textSize = 12f
            setTextColor(Color.rgb(100,100,100))
            gravity = Gravity.CENTER
        })
        r.addView(gap(34))

        r.addView(TextView(this).apply {
            text = "END MODE"
            textSize = 13f
            setTextColor(Color.rgb(150,150,150))
            gravity = Gravity.CENTER
            setPadding(20, 16, 20, 16)
            setOnClickListener {
                prefs.edit().putBoolean("simple_mode_active", false).apply()
                showHome()
            }
        })

        val update = object : Runnable {
            override fun run() {
                if (!prefs.getBoolean("simple_mode_active", false)) return
                val now = Calendar.getInstance()
                clock.text = String.format(
                    Locale.getDefault(), "%02d:%02d",
                    now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE)
                )
                handler.postDelayed(this, 1000L)
            }
        }
        timerRunnable = update
        handler.post(update)
        setContentView(r)
    }

    private fun testStatusText(): String {
        val usageGranted = try {
            val now = System.currentTimeMillis()
            val stats = usm.queryAndAggregateUsageStats(now - 60_000L, now)
            stats != null
        } catch (_: Exception) {
            false
        }
        val dumbActive = prefs.getBoolean("dumb_active", false)
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val home = packageManager.resolveActivity(homeIntent, 0)
        val homePkg = home?.activityInfo?.packageName ?: "unknown"
        return buildString {
            append("Usage Access query: ")
            append(if (usageGranted) "available" else "unavailable")
            append("\\nDumb Phone session: ")
            append(if (dumbActive) "active" else "inactive")
            append("\\nCurrent Home package: ")
            append(homePkg)
        }
    }

    private fun showSettings() {
        val r = root()
        r.addView(t("SETTINGS", 18f, true))
        r.addView(gap(10))
        r.addView(btn("USAGE ACCESS") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        r.addView(btn("SET DESTIM AS HOME") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) })
        r.addView(t("When DESTIM is your Home app, pressing Home can return you to the minimalist DESTIM screen.", 12f))
        r.addView(btn("NOTIFICATION ACCESS") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        r.addView(gap(8))
        r.addView(t("TEST STATUS", 13f, true))
        r.addView(t(testStatusText(), 13f))
        r.addView(btn("REFRESH STATUS") { showSettings() })
        r.addView(gap(12))
        r.addView(t("ABOUT DESTIM", 13f, true))
        r.addView(t("Free. No ads. No subscriptions. No Pro version.", 15f, true))
        r.addView(t(
            "DESTIM is built to help you understand your phone use and make it easier to use your phone less.",
            14f
        ))
        r.addView(gap(10))
        r.addView(btn("♡ SUPPORT DESTIM") { supportDialog() })
        r.addView(gap(8))
        r.addView(t(
            "Support is optional and does not unlock features. DESTIM remains the same for everyone.",
            12f
        ))
        r.addView(gap(14))
        r.addView(btn("BACK", ::showHome))
        setContentView(r)
    }

    private fun supportDialog() {
        AlertDialog.Builder(this)
            .setTitle("Support DESTIM")
            .setMessage("If DESTIM helps you use your phone less, you can support its development. Support is optional and does not unlock a Pro version or additional features.")
            .setPositiveButton("THANK YOU", null)
            .show()
    }

    private fun metric(r: LinearLayout, value: String, label: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(t(value, 18f, true), LinearLayout.LayoutParams(0, 52, 1f))
        row.addView(t(label, 14f).apply { gravity = Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(0, 52, 1f))
        r.addView(row)
    }

    private fun root() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(28, 30, 28, 28)
        setBackgroundColor(Color.rgb(247,247,244))
    }

    private fun t(s: String, z: Float, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = z; setTextColor(Color.rgb(25,25,25)); setPadding(0,4,0,4)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }

    private fun btn(s: String, f: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setOnClickListener { f() }
    }

    private fun gap(h: Int) = Space(this).apply { minimumHeight = h }
    private fun format(m: Long) = if (m < 60) "${m}m" else "${m/60}h ${m%60}m"
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
